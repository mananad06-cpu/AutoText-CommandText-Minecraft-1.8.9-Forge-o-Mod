package me.nasha.fourone.module;
import com.google.gson.*;
import me.nasha.fourone.autotext.Macro;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Keyboard;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
public class AutoTextModule {
    // Ruta del archivo de macros
    private static final File MACROS_FILE = new File(Minecraft.func_71410_x().field_71412_D, "AutoText/autotext-macros.json");
    private final List<Macro> macros = new ArrayList<>();
    private final Minecraft mc = Minecraft.func_71410_x();
    private boolean enabled = true;
    private boolean notifyOnBlockedInput = true;
    public AutoTextModule() {
        loadMacros();
    }
    /**
     * Se llama desde MainMod cuando se presiona una tecla en el juego (sin GUI abierta).
     * Verifica si la tecla y modificadores coinciden con algun macro activo.
     */
    public void onKeyTrigger(int pressedKey) {
        if (!enabled || mc.field_71462_r != null) return;
        boolean ctrlDown  = Keyboard.isKeyDown(Keyboard.KEY_LCONTROL) || Keyboard.isKeyDown(Keyboard.KEY_RCONTROL);
        boolean shiftDown = Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)   || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT);
        boolean altDown   = Keyboard.isKeyDown(Keyboard.KEY_LMENU)    || Keyboard.isKeyDown(Keyboard.KEY_RMENU);
        for (Macro macro : macros) {
            if (macro.isEnabled() && macro.getKeyCode() == pressedKey) {
                if (macro.isUseCtrl() == ctrlDown
                        && macro.isUseShift() == shiftDown
                        && macro.isUseAlt() == altDown) {
                    executeMacro(macro);
                }
            }
        }
    }
    /**
     * Ejecuta un macro: envia el texto al chat.
     * Si el macro es de tipo comando, agrega "/" al inicio si no lo tiene.
     */
    private void executeMacro(Macro macro) {
        if (mc.field_71439_g == null) return;
        String textToSend = macro.getText();
        if (textToSend == null || textToSend.trim().isEmpty()) return;
        if (macro.isCommand() && !textToSend.startsWith("/")) {
            textToSend = "/" + textToSend;
        }
        mc.field_71439_g.func_71165_d(textToSend);
    }
    /**
     * Muestra una notificacion en el chat cuando un envio es bloqueado.
     */
    public void triggerNotificationBlocked() {
        if (notifyOnBlockedInput && mc.field_71439_g != null) {
            mc.field_71439_g.func_145747_a(new ChatComponentText(
                    EnumChatFormatting.RED + "[AutoText] Envio bloqueado por restricciones del servidor."
            ));
        }
    }
    // ====================================================================
    //  PERSISTENCIA - Guardar y cargar macros desde JSON
    // ====================================================================
    public void saveMacros() {
        try {
            if (!MACROS_FILE.getParentFile().exists()) {
                MACROS_FILE.getParentFile().mkdirs();
            }
            JsonObject root = new JsonObject();
            JsonArray array = new JsonArray();
            for (Macro m : macros) {
                JsonObject obj = new JsonObject();
                obj.addProperty("name",      m.getName());
                obj.addProperty("text",      m.getText());
                obj.addProperty("keyCode",   m.getKeyCode());
                obj.addProperty("useCtrl",   m.isUseCtrl());
                obj.addProperty("useShift",  m.isUseShift());
                obj.addProperty("useAlt",    m.isUseAlt());
                obj.addProperty("enabled",   m.isEnabled());
                obj.addProperty("isCommand", m.isCommand());
                array.add(obj);
            }
            root.add("macros", array);
            try (FileWriter writer = new FileWriter(MACROS_FILE)) {
                new GsonBuilder().setPrettyPrinting().create().toJson(root, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void loadMacros() {
        if (!MACROS_FILE.exists()) {
            // Crear macros de ejemplo por defecto
            macros.add(new Macro("Soporte",   "/help",         Keyboard.KEY_H, false, false, false, true, true));
            macros.add(new Macro("Clan Chat", "Hola equipo!",  Keyboard.KEY_C, true,  false, false, true, false));
            saveMacros();
            return;
        }
        try (FileReader reader = new FileReader(MACROS_FILE)) {
            JsonObject json = new JsonParser().parse(reader).getAsJsonObject();
            JsonArray array = json.getAsJsonArray("macros");
            macros.clear();
            for (JsonElement el : array) {
                JsonObject obj = el.getAsJsonObject();
                macros.add(new Macro(
                        obj.get("name").getAsString(),
                        obj.get("text").getAsString(),
                        obj.get("keyCode").getAsInt(),
                        obj.has("useCtrl")  ? obj.get("useCtrl").getAsBoolean()  : false,
                        obj.has("useShift") ? obj.get("useShift").getAsBoolean() : false,
                        obj.has("useAlt")   ? obj.get("useAlt").getAsBoolean()   : false,
                        obj.get("enabled").getAsBoolean(),
                        obj.get("isCommand").getAsBoolean()
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // ====================================================================
    //  GETTERS / SETTERS
    // ====================================================================
    public List<Macro> getMacros()       { return macros; }
    public boolean isEnabled()           { return enabled; }
    public void setEnabled(boolean val)  { this.enabled = val; }
    public boolean isNotifyOnBlockedInput()          { return notifyOnBlockedInput; }
    public void setNotifyOnBlockedInput(boolean val) { this.notifyOnBlockedInput = val; }
}