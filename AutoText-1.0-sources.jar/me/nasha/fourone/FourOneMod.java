package me.nasha.fourone;



import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

@Mod(modid = FourOneMod.MODID, name = FourOneMod.NAME, version = FourOneMod.VERSION)
public class FourOneMod {
    public static final String MODID = "fourone";
    public static final String NAME = "SystemMonitor";
    public static final String VERSION = "1.0";

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // ✅ AQUÍ SE INICIALIZA TODO (antes faltaba esto)
        
    }
}