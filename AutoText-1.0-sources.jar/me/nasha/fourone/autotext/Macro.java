package me.nasha.fourone.autotext;
import org.lwjgl.input.Keyboard;
public class Macro {
    private String name;
    private String text;
    private int keyCode;
    private boolean useCtrl;
    private boolean useShift;
    private boolean useAlt;
    private boolean enabled;
    private boolean isCommand;
    public Macro(String name, String text, int keyCode, boolean useCtrl, boolean useShift, boolean useAlt, boolean enabled, boolean isCommand) {
        this.name = name;
        this.text = text;
        this.keyCode = keyCode;
        this.useCtrl = useCtrl;
        this.useShift = useShift;
        this.useAlt = useAlt;
        this.enabled = enabled;
        this.isCommand = isCommand;
    }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public int getKeyCode() { return keyCode; }
    public void setKeyCode(int keyCode) { this.keyCode = keyCode; }
    public boolean isUseCtrl() { return useCtrl; }
    public void setUseCtrl(boolean useCtrl) { this.useCtrl = useCtrl; }
    public boolean isUseShift() { return useShift; }
    public void setUseShift(boolean useShift) { this.useShift = useShift; }
    public boolean isUseAlt() { return useAlt; }
    public void setUseAlt(boolean useAlt) { this.useAlt = useAlt; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public boolean isCommand() { return isCommand; }
    public void setCommand(boolean command) { this.isCommand = command; }
    public String getFullComboName() {
        if (keyCode == Keyboard.KEY_NONE || keyCode == 0) return "NONE";
        StringBuilder sb = new StringBuilder();
        if (useCtrl) sb.append("CTRL + ");
        if (useShift) sb.append("SHIFT + ");
        if (useAlt) sb.append("ALT + ");
        sb.append(Keyboard.getKeyName(keyCode));
        return sb.toString();
    }
}
