package me.nasha.fourone.gui.autotext;
import me.nasha.fourone.autotext.Macro;

import me.nasha.fourone.module.AutoTextModule;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import java.io.IOException;
public class AutoTextPanel extends GuiScreen {
    private final AutoTextModule module;
    // Dimensiones del panel
    private int panelX, panelY;
    private int panelWidth = 420;
    private int panelHeight = 300;
    // Vistas: 0 = Lista de macros, 1 = Editar/Crear macro
    private int currentView = 0;
    // Scroll para la lista
    private int scrollOffset = 0;
    private static final int ENTRY_HEIGHT = 52;
    private static final int HEADER_HEIGHT = 38;
    // Estado de edicion
    private Macro editingMacro = null;
    private boolean isNewMacro = false;
    private GuiTextField nameField;
    private GuiTextField contentField;
    private boolean waitingForKey = false;
    // Colores del tema oscuro
    private static final int COL_PANEL_BG    = 0xEE111122;
    private static final int COL_HEADER_BG   = 0xFF0D0D1A;
    private static final int COL_ENTRY_BG    = 0xFF1A1A33;
    private static final int COL_ENTRY_HOVER = 0xFF252550;
    private static final int COL_BORDER      = 0xFF333366;
    private static final int COL_ACCENT      = 0xFF00D4AA;
    private static final int COL_RED         = 0xFFFF4455;
    private static final int COL_GREEN_TXT   = 0xFF55FF55;
    private static final int COL_CYAN_TXT    = 0xFF55FFFF;
    private static final int COL_WHITE       = 0xFFFFFFFF;
    private static final int COL_DIM         = 0xFF888888;
    private static final int COL_TOGGLE_ON   = 0xFF00AA44;
    private static final int COL_TOGGLE_OFF  = 0xFF444455;
    private static final int COL_BTN_SAVE    = 0xFF2255AA;
    private static final int COL_BTN_DEL     = 0xFFAA2222;
    private static final int COL_KEYBIND_BG  = 0xFF222244;
    private static final int COL_KEYWAIT_BG  = 0xFFAA5500;
    private static final int COL_SCROLLBAR   = 0xAACCCCCC;
    private static final int COL_ADD_BTN     = 0xFF005544;
    public AutoTextPanel(AutoTextModule module) {
        this.module = module;
    }
    @Override
    public void func_73866_w_() {
        this.panelWidth  = Math.min(430, this.field_146294_l - 30);
        this.panelHeight = Math.min(320, this.field_146295_m - 30);
        this.panelX = (this.field_146294_l  - panelWidth)  / 2;
        this.panelY = (this.field_146295_m - panelHeight) / 2;
        // Si estamos en vista de edicion, reiniciar los campos con nuevas coordenadas
        if (currentView == 1 && editingMacro != null) {
            initEditFields();
        }
    }
    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        if (currentView == 0) {
            drawListView(mouseX, mouseY);
        } else {
            drawEditView(mouseX, mouseY);
        }
    }
    // ====================================================================
    //  VISTA DE LISTA - Muestra todos los macros con scroll
    // ====================================================================
    private void drawListView(int mouseX, int mouseY) {
        // Fondo del panel
        func_73734_a(panelX, panelY, panelX + panelWidth, panelY + panelHeight, COL_PANEL_BG);
        drawBorder(panelX, panelY, panelX + panelWidth, panelY + panelHeight, COL_BORDER);
        // ---- Barra de encabezado ----
        func_73734_a(panelX, panelY, panelX + panelWidth, panelY + HEADER_HEIGHT, COL_HEADER_BG);
        func_73734_a(panelX, panelY + HEADER_HEIGHT - 1, panelX + panelWidth, panelY + HEADER_HEIGHT, COL_BORDER);
        // Flecha de retroceso <-
        int arrowBtnX1 = panelX + 6;
        int arrowBtnY1 = panelY + 8;
        int arrowBtnX2 = panelX + 26;
        int arrowBtnY2 = panelY + HEADER_HEIGHT - 8;
        boolean arrowHover = mouseX >= arrowBtnX1 && mouseX <= arrowBtnX2 && mouseY >= arrowBtnY1 && mouseY <= arrowBtnY2;
        func_73734_a(arrowBtnX1, arrowBtnY1, arrowBtnX2, arrowBtnY2, arrowHover ? COL_ENTRY_HOVER : 0xFF1A1A33);
        field_146289_q.func_175063_a("\u2190", arrowBtnX1 + 5, arrowBtnY1 + 3, COL_WHITE);
        // Titulo
        field_146289_q.func_175063_a("Centro de Control de AutoText", panelX + 32, panelY + 13, COL_WHITE);
        // Boton cerrar [-]
        String closeStr = "[-]";
        int closeW = field_146289_q.func_78256_a(closeStr);
        int closeX = panelX + panelWidth - closeW - 10;
        boolean closeHover = mouseX >= closeX && mouseX <= closeX + closeW && mouseY >= panelY + 8 && mouseY <= panelY + 22;
        field_146289_q.func_175063_a(closeStr, closeX, panelY + 13, closeHover ? COL_RED : COL_DIM);
        // ---- Barra de descripcion + boton Agregar ----
        int descY = panelY + HEADER_HEIGHT + 4;
        field_146289_q.func_175063_a("Le permite configurar macros de texto automatico.", panelX + 8, descY, COL_DIM);
        // Boton "+ Agregar"
        int addW = 68;
        int addH = 14;
        int addX = panelX + panelWidth - addW - 8;
        int addY = descY - 1;
        boolean addHover = mouseX >= addX && mouseX <= addX + addW && mouseY >= addY && mouseY <= addY + addH;
        func_73734_a(addX, addY, addX + addW, addY + addH, addHover ? COL_ACCENT : COL_ADD_BTN);
        field_146289_q.func_175063_a("+ Agregar", addX + 6, addY + 3, COL_WHITE);
        // ---- Area de lista scrolleable ----
        int listTop    = panelY + HEADER_HEIGHT + 20;
        int listBottom = panelY + panelHeight - 4;
        int listHeight = listBottom - listTop;
        int totalItems = module.getMacros().size();
        int totalContentHeight = totalItems * ENTRY_HEIGHT;
        int maxScroll = Math.max(0, totalContentHeight - listHeight);
        scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));
        // Habilitar scissor para recortar el contenido
        enableScissor(panelX + 1, listTop, panelX + panelWidth - 1, listBottom);
        int yPos = listTop - scrollOffset;
        for (int i = 0; i < totalItems; i++) {
            Macro m = module.getMacros().get(i);
            int entryTop    = yPos;
            int entryBottom = yPos + ENTRY_HEIGHT - 3;
            // Solo dibujar si esta dentro del area visible (con margen)
            if (entryBottom > listTop - ENTRY_HEIGHT && entryTop < listBottom + ENTRY_HEIGHT) {
                boolean entryHover = mouseX >= panelX + 4 && mouseX <= panelX + panelWidth - 4
                        && mouseY >= Math.max(entryTop, listTop) && mouseY < Math.min(entryBottom, listBottom);
                // Fondo de la entrada
                func_73734_a(panelX + 4, entryTop, panelX + panelWidth - 4, entryBottom, entryHover ? COL_ENTRY_HOVER : COL_ENTRY_BG);
                // Linea 1: Nombre del macro + indicadores
                String nameStr = m.getName();
                field_146289_q.func_175063_a(nameStr, panelX + 12, entryTop + 5, COL_WHITE);
                // Indicador CMD
                if (m.isCommand()) {
                    int cmdTagX = panelX + 12 + field_146289_q.func_78256_a(nameStr) + 6;
                    func_73734_a(cmdTagX, entryTop + 3, cmdTagX + 30, entryTop + 15, 0xFF005500);
                    field_146289_q.func_175063_a("CMD", cmdTagX + 4, entryTop + 5, COL_GREEN_TXT);
                }
                // ON/OFF a la derecha
                String statusStr = m.isEnabled() ? "ON" : "OFF";
                int statusColor  = m.isEnabled() ? COL_GREEN_TXT : COL_RED;
                int statusX = panelX + panelWidth - field_146289_q.func_78256_a(statusStr) - 14;
                field_146289_q.func_175063_a(statusStr, statusX, entryTop + 5, statusColor);
                // Linea 2: Texto/contenido (preview)
                String preview = m.getText();
                int maxPreviewWidth = panelWidth - 30;
                if (field_146289_q.func_78256_a(preview) > maxPreviewWidth) {
                    while (field_146289_q.func_78256_a(preview + "...") > maxPreviewWidth && preview.length() > 0) {
                        preview = preview.substring(0, preview.length() - 1);
                    }
                    preview = preview + "...";
                }
                field_146289_q.func_175063_a(preview, panelX + 12, entryTop + 19, COL_DIM);
                // Linea 3: Tecla de acceso + boton Editar
                String keyName = m.getFullComboName();
                int keyColor = keyName.equals("NONE") ? COL_GREEN_TXT : COL_CYAN_TXT;
                field_146289_q.func_175063_a("[" + keyName + "]", panelX + 12, entryTop + 33, keyColor);
                // Boton [Editar]
                String editStr = "[Editar]";
                int editW = field_146289_q.func_78256_a(editStr);
                field_146289_q.func_175063_a(editStr, panelX + panelWidth - editW - 14, entryTop + 33, COL_ACCENT);
            }
            yPos += ENTRY_HEIGHT;
        }
        disableScissor();
        // Si no hay macros, mostrar mensaje
        if (totalItems == 0) {
            String emptyMsg = "No hay macros. Haz clic en '+ Agregar' para crear uno.";
            int emptyW = field_146289_q.func_78256_a(emptyMsg);
            field_146289_q.func_175063_a(emptyMsg, panelX + (panelWidth - emptyW) / 2, listTop + 30, COL_DIM);
        }
        // Barra de scroll
        if (totalContentHeight > listHeight && maxScroll > 0) {
            int scrollBarTotalH = listHeight;
            int scrollBarH = Math.max(15, (int) ((float) listHeight / totalContentHeight * scrollBarTotalH));
            int scrollBarY = listTop + (int) ((float) scrollOffset / maxScroll * (scrollBarTotalH - scrollBarH));
            func_73734_a(panelX + panelWidth - 5, scrollBarY, panelX + panelWidth - 2, scrollBarY + scrollBarH, COL_SCROLLBAR);
        }
    }
    // ====================================================================
    //  VISTA DE EDICION - Editar o crear un macro individual
    // ====================================================================
    private void drawEditView(int mouseX, int mouseY) {
        // Fondo del panel
        func_73734_a(panelX, panelY, panelX + panelWidth, panelY + panelHeight, COL_PANEL_BG);
        drawBorder(panelX, panelY, panelX + panelWidth, panelY + panelHeight, COL_BORDER);
        // ---- Barra de encabezado ----
        func_73734_a(panelX, panelY, panelX + panelWidth, panelY + HEADER_HEIGHT, COL_HEADER_BG);
        func_73734_a(panelX, panelY + HEADER_HEIGHT - 1, panelX + panelWidth, panelY + HEADER_HEIGHT, COL_BORDER);
        // Flecha de retroceso <-
        int arrowBtnX1 = panelX + 6;
        int arrowBtnY1 = panelY + 8;
        int arrowBtnX2 = panelX + 26;
        int arrowBtnY2 = panelY + HEADER_HEIGHT - 8;
        boolean arrowHover = mouseX >= arrowBtnX1 && mouseX <= arrowBtnX2 && mouseY >= arrowBtnY1 && mouseY <= arrowBtnY2;
        func_73734_a(arrowBtnX1, arrowBtnY1, arrowBtnX2, arrowBtnY2, arrowHover ? COL_ENTRY_HOVER : 0xFF1A1A33);
        field_146289_q.func_175063_a("\u2190", arrowBtnX1 + 5, arrowBtnY1 + 3, COL_WHITE);
        // Titulo
        String editTitle = isNewMacro ? "Crear Nuevo Macro" : "Editar Macro";
        field_146289_q.func_175063_a(editTitle, panelX + 32, panelY + 13, COL_WHITE);
        // ---- Contenido del formulario ----
        int baseY = panelY + HEADER_HEIGHT + 10;
        int fieldWidth = panelWidth - 36;
        // Campo: Nombre
        field_146289_q.func_175063_a("Nombre:", panelX + 15, baseY, COL_WHITE);
        if (nameField != null) nameField.func_146194_f();
        // Campo: Texto del macro
        field_146289_q.func_175063_a("Texto / Comando (Max 250 caracteres):", panelX + 15, baseY + 42, COL_WHITE);
        if (contentField != null) contentField.func_146194_f();
        // ---- Tecla de activacion ----
        int keyY = baseY + 86;
        field_146289_q.func_175063_a("Tecla:", panelX + 15, keyY, COL_WHITE);
        int keyBoxX1 = panelX + 55;
        int keyBoxX2 = panelX + panelWidth - 18;
        int keyBoxY1 = keyY - 3;
        int keyBoxY2 = keyY + 12;
        if (waitingForKey) {
            func_73734_a(keyBoxX1, keyBoxY1, keyBoxX2, keyBoxY2, COL_KEYWAIT_BG);
            field_146289_q.func_175063_a("[ Presiona una tecla... ]", keyBoxX1 + 5, keyY, COL_WHITE);
        } else {
            func_73734_a(keyBoxX1, keyBoxY1, keyBoxX2, keyBoxY2, COL_KEYBIND_BG);
            String keyStr = editingMacro != null ? editingMacro.getFullComboName() : "NONE";
            field_146289_q.func_175063_a("[ " + keyStr + " ]", keyBoxX1 + 5, keyY, COL_GREEN_TXT);
        }
        field_146289_q.func_175063_a("(Clic para cambiar)", keyBoxX1 + 5, keyY + 14, COL_DIM);
        // ---- Modificadores (checkboxes) ----
        int modY = keyY + 28;
        field_146289_q.func_175063_a("Modificadores:", panelX + 15, modY, COL_WHITE);
        if (editingMacro != null) {
            drawCheckbox(panelX + 110, modY, "CTRL",  editingMacro.isUseCtrl(),  mouseX, mouseY);
            drawCheckbox(panelX + 180, modY, "SHIFT", editingMacro.isUseShift(), mouseX, mouseY);
            drawCheckbox(panelX + 255, modY, "ALT",   editingMacro.isUseAlt(),   mouseX, mouseY);
        }
        // ---- Toggles: Comando y Activado ----
        int toggleY = modY + 22;
        // Toggle Comando
        field_146289_q.func_175063_a("Comando:", panelX + 15, toggleY, COL_WHITE);
        boolean isCmd = editingMacro != null && editingMacro.isCommand();
        int cmdBtnX = panelX + 80;
        int cmdBtnColor = isCmd ? COL_TOGGLE_ON : COL_TOGGLE_OFF;
        boolean cmdHover = mouseX >= cmdBtnX && mouseX <= cmdBtnX + 36 && mouseY >= toggleY - 2 && mouseY <= toggleY + 12;
        func_73734_a(cmdBtnX, toggleY - 2, cmdBtnX + 36, toggleY + 12, cmdHover ? (cmdBtnColor + 0x111111) : cmdBtnColor);
        field_146289_q.func_175063_a(isCmd ? " ON" : " OFF", cmdBtnX + 5, toggleY, COL_WHITE);
        // Toggle Activado
        field_146289_q.func_175063_a("Activado:", panelX + 150, toggleY, COL_WHITE);
        boolean isOn = editingMacro != null && editingMacro.isEnabled();
        int onBtnX = panelX + 220;
        int onBtnColor = isOn ? COL_TOGGLE_ON : COL_TOGGLE_OFF;
        boolean onHover = mouseX >= onBtnX && mouseX <= onBtnX + 36 && mouseY >= toggleY - 2 && mouseY <= toggleY + 12;
        func_73734_a(onBtnX, toggleY - 2, onBtnX + 36, toggleY + 12, onHover ? (onBtnColor + 0x111111) : onBtnColor);
        field_146289_q.func_175063_a(isOn ? " ON" : " OFF", onBtnX + 5, toggleY, COL_WHITE);
        // ---- Botones de accion ----
        int btnY = toggleY + 26;
        int btnH = 20;
        // Boton GUARDAR
        int saveBtnX1 = panelX + 15;
        int saveBtnX2 = panelX + 110;
        boolean saveHover = mouseX >= saveBtnX1 && mouseX <= saveBtnX2 && mouseY >= btnY && mouseY <= btnY + btnH;
        func_73734_a(saveBtnX1, btnY, saveBtnX2, btnY + btnH, saveHover ? 0xFF3366CC : COL_BTN_SAVE);
        func_73732_a(field_146289_q, "GUARDAR", (saveBtnX1 + saveBtnX2) / 2, btnY + 6, COL_WHITE);
        // Boton ELIMINAR
        int delBtnX1 = panelX + panelWidth - 110;
        int delBtnX2 = panelX + panelWidth - 15;
        boolean delHover = mouseX >= delBtnX1 && mouseX <= delBtnX2 && mouseY >= btnY && mouseY <= btnY + btnH;
        func_73734_a(delBtnX1, btnY, delBtnX2, btnY + btnH, delHover ? 0xFFCC3333 : COL_BTN_DEL);
        func_73732_a(field_146289_q, "ELIMINAR", (delBtnX1 + delBtnX2) / 2, btnY + 6, COL_WHITE);
    }
    // ====================================================================
    //  HELPERS DE DIBUJO
    // ====================================================================
    private void drawCheckbox(int x, int y, String label, boolean checked, int mouseX, int mouseY) {
        int boxSize = 12;
        boolean hover = mouseX >= x && mouseX <= x + boxSize && mouseY >= y && mouseY <= y + boxSize;
        func_73734_a(x, y, x + boxSize, y + boxSize, checked ? COL_ACCENT : (hover ? 0xFF444466 : 0xFF333355));
        drawBorder(x, y, x + boxSize, y + boxSize, COL_BORDER);
        if (checked) {
            field_146289_q.func_175063_a("x", x + 3, y + 2, 0xFF000000);
        }
        field_146289_q.func_175063_a(label, x + boxSize + 4, y + 2, COL_WHITE);
    }
    private void drawBorder(int x1, int y1, int x2, int y2, int color) {
        func_73734_a(x1, y1, x2, y1 + 1, color);     // top
        func_73734_a(x1, y2 - 1, x2, y2, color);      // bottom
        func_73734_a(x1, y1, x1 + 1, y2, color);      // left
        func_73734_a(x2 - 1, y1, x2, y2, color);      // right
    }
    private void enableScissor(int x1, int y1, int x2, int y2) {
        int scaleFactor = this.field_146297_k.field_71474_y != null ? new net.minecraft.client.gui.ScaledResolution(this.field_146297_k).func_78325_e() : 1;
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(
                x1 * scaleFactor,
                (this.field_146295_m - y2) * scaleFactor,
                (x2 - x1) * scaleFactor,
                (y2 - y1) * scaleFactor
        );
    }
    private void disableScissor() {
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }
    // ====================================================================
    //  MANEJO DE INPUT
    // ====================================================================
    @Override
    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (currentView == 0) {
            handleListClick(mouseX, mouseY, mouseButton);
        } else {
            handleEditClick(mouseX, mouseY, mouseButton);
        }
    }
    private void handleListClick(int mouseX, int mouseY, int mouseButton) {
        // ---- Flecha de retroceso -> volver al chat ----
        if (mouseX >= panelX + 6 && mouseX <= panelX + 26 && mouseY >= panelY + 8 && mouseY <= panelY + HEADER_HEIGHT - 8) {
            field_146297_k.func_147108_a(new GuiChat(""));
            return;
        }
        // ---- Boton cerrar [-] ----
        String closeStr = "[-]";
        int closeW = field_146289_q.func_78256_a(closeStr);
        int closeX = panelX + panelWidth - closeW - 10;
        if (mouseX >= closeX && mouseX <= closeX + closeW + 4 && mouseY >= panelY + 8 && mouseY <= panelY + 24) {
            field_146297_k.func_147108_a(null);
            return;
        }
        // ---- Boton "+ Agregar" ----
        int addW = 68;
        int addX = panelX + panelWidth - addW - 8;
        int addY = panelY + HEADER_HEIGHT + 3;
        if (mouseX >= addX && mouseX <= addX + addW && mouseY >= addY && mouseY <= addY + 14) {
            editingMacro = new Macro("Nuevo Macro", "", 0, false, false, false, true, false);
            module.getMacros().add(editingMacro);
            isNewMacro = true;
            initEditFields();
            currentView = 1;
            return;
        }
        // ---- Click en entradas de la lista ----
        int listTop    = panelY + HEADER_HEIGHT + 20;
        int listBottom = panelY + panelHeight - 4;
        int yPos = listTop - scrollOffset;
        for (int i = 0; i < module.getMacros().size(); i++) {
            Macro m = module.getMacros().get(i);
            int entryTop    = yPos;
            int entryBottom = yPos + ENTRY_HEIGHT - 3;
            if (entryBottom > listTop && entryTop < listBottom) {
                if (mouseX >= panelX + 4 && mouseX <= panelX + panelWidth - 4
                        && mouseY >= Math.max(entryTop, listTop) && mouseY < Math.min(entryBottom, listBottom)) {
                    // Abrir vista de edicion para este macro
                    editingMacro = m;
                    isNewMacro = false;
                    initEditFields();
                    currentView = 1;
                    return;
                }
            }
            yPos += ENTRY_HEIGHT;
        }
    }
    private void handleEditClick(int mouseX, int mouseY, int mouseButton) {
        // Pasar clicks a los campos de texto
        if (nameField != null)    nameField.func_146192_a(mouseX, mouseY, mouseButton);
        if (contentField != null) contentField.func_146192_a(mouseX, mouseY, mouseButton);
        // ---- Flecha de retroceso -> volver a la lista ----
        if (mouseX >= panelX + 6 && mouseX <= panelX + 26 && mouseY >= panelY + 8 && mouseY <= panelY + HEADER_HEIGHT - 8) {
            // Si era un macro nuevo y el usuario cancela, eliminar
            if (isNewMacro && editingMacro != null) {
                if (editingMacro.getName().equals("Nuevo Macro") && editingMacro.getText().isEmpty()) {
                    module.getMacros().remove(editingMacro);
                }
            }
            currentView = 0;
            waitingForKey = false;
            editingMacro = null;
            return;
        }
        int baseY = panelY + HEADER_HEIGHT + 10;
        // ---- Click en area de tecla ----
        int keyY = baseY + 86;
        int keyBoxX1 = panelX + 55;
        int keyBoxX2 = panelX + panelWidth - 18;
        if (mouseX >= keyBoxX1 && mouseX <= keyBoxX2 && mouseY >= keyY - 3 && mouseY <= keyY + 12) {
            waitingForKey = true;
            return;
        }
        // ---- Checkboxes de modificadores ----
        int modY = keyY + 28;
        if (editingMacro != null) {
            // CTRL checkbox
            if (mouseX >= panelX + 110 && mouseX <= panelX + 122 && mouseY >= modY && mouseY <= modY + 12) {
                editingMacro.setUseCtrl(!editingMacro.isUseCtrl());
                return;
            }
            // SHIFT checkbox
            if (mouseX >= panelX + 180 && mouseX <= panelX + 192 && mouseY >= modY && mouseY <= modY + 12) {
                editingMacro.setUseShift(!editingMacro.isUseShift());
                return;
            }
            // ALT checkbox
            if (mouseX >= panelX + 255 && mouseX <= panelX + 267 && mouseY >= modY && mouseY <= modY + 12) {
                editingMacro.setUseAlt(!editingMacro.isUseAlt());
                return;
            }
        }
        // ---- Toggles: Comando y Activado ----
        int toggleY = modY + 22;
        // Toggle Comando
        int cmdBtnX = panelX + 80;
        if (mouseX >= cmdBtnX && mouseX <= cmdBtnX + 36 && mouseY >= toggleY - 2 && mouseY <= toggleY + 12) {
            if (editingMacro != null) editingMacro.setCommand(!editingMacro.isCommand());
            return;
        }
        // Toggle Activado
        int onBtnX = panelX + 220;
        if (mouseX >= onBtnX && mouseX <= onBtnX + 36 && mouseY >= toggleY - 2 && mouseY <= toggleY + 12) {
            if (editingMacro != null) editingMacro.setEnabled(!editingMacro.isEnabled());
            return;
        }
        // ---- Botones de accion ----
        int btnY = toggleY + 26;
        int btnH = 20;
        // Boton GUARDAR
        if (mouseX >= panelX + 15 && mouseX <= panelX + 110 && mouseY >= btnY && mouseY <= btnY + btnH) {
            if (editingMacro != null && nameField != null && contentField != null) {
                editingMacro.setName(nameField.func_146179_b());
                editingMacro.setText(contentField.func_146179_b());
                module.saveMacros();
                isNewMacro = false;
                currentView = 0;
                editingMacro = null;
            }
            return;
        }
        // Boton ELIMINAR
        if (mouseX >= panelX + panelWidth - 110 && mouseX <= panelX + panelWidth - 15
                && mouseY >= btnY && mouseY <= btnY + btnH) {
            if (editingMacro != null) {
                module.getMacros().remove(editingMacro);
                module.saveMacros();
                editingMacro = null;
                currentView = 0;
            }
            return;
        }
    }
    // ====================================================================
    //  INICIALIZACION DE CAMPOS DE TEXTO
    // ====================================================================
    private void initEditFields() {
        int baseY = panelY + HEADER_HEIGHT + 10;
        int fieldWidth = panelWidth - 36;
        nameField = new GuiTextField(0, field_146289_q, panelX + 18, baseY + 12, fieldWidth, 18);
        nameField.func_146203_f(50);
        nameField.func_146195_b(true);
        if (editingMacro != null) nameField.func_146180_a(editingMacro.getName());
        contentField = new GuiTextField(1, field_146289_q, panelX + 18, baseY + 54, fieldWidth, 18);
        contentField.func_146203_f(250);
        if (editingMacro != null) contentField.func_146180_a(editingMacro.getText());
    }
    // ====================================================================
    //  MANEJO DE TECLADO
    // ====================================================================
    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (currentView == 1) {
            // Modo captura de tecla
            if (waitingForKey) {
                if (keyCode == Keyboard.KEY_ESCAPE) {
                    // Cancelar captura
                    waitingForKey = false;
                    return;
                }
                if (keyCode == Keyboard.KEY_DELETE || keyCode == Keyboard.KEY_BACK) {
                    // Limpiar tecla asignada
                    if (editingMacro != null) {
                        editingMacro.setKeyCode(0);
                    }
                    waitingForKey = false;
                    return;
                }
                // No asignar teclas modificadoras solas
                if (keyCode != Keyboard.KEY_LCONTROL && keyCode != Keyboard.KEY_RCONTROL
                        && keyCode != Keyboard.KEY_LSHIFT && keyCode != Keyboard.KEY_RSHIFT
                        && keyCode != Keyboard.KEY_LMENU && keyCode != Keyboard.KEY_RMENU) {
                    if (editingMacro != null) {
                        editingMacro.setKeyCode(keyCode);
                    }
                    waitingForKey = false;
                }
                return;
            }
            // Pasar teclas a los campos de texto
            if (nameField != null)    nameField.func_146201_a(typedChar, keyCode);
            if (contentField != null) contentField.func_146201_a(typedChar, keyCode);
            // ESC para volver a la lista
            if (keyCode == Keyboard.KEY_ESCAPE) {
                if (isNewMacro && editingMacro != null) {
                    if (editingMacro.getName().equals("Nuevo Macro") && editingMacro.getText().isEmpty()) {
                        module.getMacros().remove(editingMacro);
                    }
                }
                currentView = 0;
                waitingForKey = false;
                editingMacro = null;
            }
        } else {
            // En la lista, ESC cierra el panel
            if (keyCode == Keyboard.KEY_ESCAPE) {
                field_146297_k.func_147108_a(null);
            }
        }
    }
    // ====================================================================
    //  MANEJO DE SCROLL
    // ====================================================================
    @Override
    public void func_146274_d() throws IOException {
        super.func_146274_d();
        if (currentView == 0) {
            int wheel = Mouse.getEventDWheel();
            if (wheel != 0) {
                int scrollAmount = 25;
                scrollOffset += (wheel > 0) ? -scrollAmount : scrollAmount;
                int totalContentHeight = module.getMacros().size() * ENTRY_HEIGHT;
                int listHeight = (panelY + panelHeight - 4) - (panelY + HEADER_HEIGHT + 20);
                int maxScroll = Math.max(0, totalContentHeight - listHeight);
                scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));
            }
        }
    }
    // ====================================================================
    //  UTILIDADES
    // ====================================================================
    /** Usado por ClickGui para saber si debe bloquear el manejo de teclado */
    public boolean isEditing() {
        return currentView == 1;
    }
    @Override
    public boolean func_73868_f() {
        return false;
    }
    @Override
    public void func_146281_b() {
        module.saveMacros();
    }
}