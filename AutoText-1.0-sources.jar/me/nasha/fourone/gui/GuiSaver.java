package me.nasha.fourone.gui;
import com.google.gson.Gson;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class GuiSaver {
    private static final File DIR = new File(Minecraft.func_71410_x().field_71412_D, "AutoText");
    private static final File FILE = new File(DIR, "gui_positions.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static JsonObject positionsData = new JsonObject();
    public static void loadPositions() {
        if (!FILE.exists()) return;
        try (FileReader reader = new FileReader(FILE)) {
            positionsData = new JsonParser().parse(reader).getAsJsonObject();
        } catch (Exception e) {
            System.err.println("Error cargando posiciones del GUI.");
        }
    }
    public static void savePositions() {
        if (!DIR.exists()) DIR.mkdirs();
        try (FileWriter writer = new FileWriter(FILE)) {
            GSON.toJson(positionsData, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void updatePanelPosition(String panelName, int x, int y) {
        JsonObject panelCoords = new JsonObject();
        panelCoords.addProperty("x", x);
        panelCoords.addProperty("y", y);
        positionsData.add(panelName, panelCoords);
    }
    public static int[] getPanelPosition(String panelName, int defaultX, int defaultY) {
        if (positionsData.has(panelName)) {
            JsonObject coords = positionsData.getAsJsonObject(panelName);
            int x = coords.has("x") ? coords.get("x").getAsInt() : defaultX;
            int y = coords.has("y") ? coords.get("y").getAsInt() : defaultY;
            return new int[]{x, y};
        }
        return new int[]{defaultX, defaultY};
    }
}