package me.nasha.fourone.gui;
import me.nasha.fourone.MainMod;
import me.nasha.fourone.gui.autotext.AutoTextPanel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiChat;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
public class GuiChatInjector {
    @SubscribeEvent
    public void onInitGui(GuiScreenEvent.InitGuiEvent.Post event) {
        if (event.gui instanceof GuiChat) {
            // Boton "Config AutoText" en la esquina superior derecha del chat
            int buttonWidth = 100;
            int posX = event.gui.field_146294_l - buttonWidth - 2;
            int posY = 2;
            event.buttonList.add(new GuiButton(999, posX, posY, buttonWidth, 20, "Config AutoText"));
        }
    }
    @SubscribeEvent
    public void onActionPerformed(GuiScreenEvent.ActionPerformedEvent.Post event) {
        if (event.gui instanceof GuiChat && event.button.field_146127_k == 999) {
            // Abre el panel de AutoText al hacer clic en el boton
            Minecraft.func_71410_x().func_147108_a(
                new AutoTextPanel(MainMod.instance.getAutoTextModule())
            );
        }
    }
}
