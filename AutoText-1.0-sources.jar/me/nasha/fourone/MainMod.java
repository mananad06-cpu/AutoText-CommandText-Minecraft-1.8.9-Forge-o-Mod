package me.nasha.fourone;
import me.nasha.fourone.gui.GuiChatInjector;

import net.minecraft.client.Minecraft;

import me.nasha.fourone.gui.GuiSaver;
import me.nasha.fourone.module.AutoTextModule;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;
@Mod(modid = MainMod.MODID, name = MainMod.NAME, version = MainMod.VERSION)
public class MainMod {
    public static final String MODID = "AutoText";
    public static final String NAME = "AutoText";
    public static final String VERSION = "1.2";
    @Mod.Instance(MODID)
    public static MainMod instance;
    private AutoTextModule autoTextModule;
    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        instance = this;
        GuiSaver.loadPositions();
        this.autoTextModule = new AutoTextModule();
        // Registrar manejadores de eventos
        MinecraftForge.EVENT_BUS.register(this);
        
        MinecraftForge.EVENT_BUS.register(new GuiChatInjector());
    }
    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (Minecraft.func_71410_x().field_71439_g == null) return;
        if (Keyboard.getEventKeyState()) {
            int keyCode = Keyboard.getEventKey();
            // Llamada directa al modulo para activar macros
            autoTextModule.onKeyTrigger(keyCode);
        }
    }
    public AutoTextModule getAutoTextModule() {
        return this.autoTextModule;
    }
}